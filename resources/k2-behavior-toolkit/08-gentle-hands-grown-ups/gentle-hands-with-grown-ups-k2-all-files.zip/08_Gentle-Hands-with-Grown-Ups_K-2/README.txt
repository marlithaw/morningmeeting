Gentle Hands with Grown-Ups · K-2 Behavior Toolkit · Topic 8 of 12
Matchbook Learning Morning Meeting

Open gentle-hands-grown-ups-student-deck-k2.html in Chrome to teach. Press N for notes.
Slide 1 has a Play the song button. Keep gentle-hands-grown-ups-song.mp4 in this same folder so it plays.

Lee & Tee characters (c) AH-HA Coaching and Consulting, used with permission.
