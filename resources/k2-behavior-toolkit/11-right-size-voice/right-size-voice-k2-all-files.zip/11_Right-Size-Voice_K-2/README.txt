Right-Size Voice · K-2 Behavior Toolkit · Topic 11 of 12
Matchbook Learning Morning Meeting

Open right-size-voice-student-deck-k2.html in Chrome to teach. Press N for notes.
Slide 1 has a Play the song button. Keep right-size-voice-song.mp4 in this same folder so it plays.

Lee & Tee characters (c) AH-HA Coaching and Consulting, used with permission.
