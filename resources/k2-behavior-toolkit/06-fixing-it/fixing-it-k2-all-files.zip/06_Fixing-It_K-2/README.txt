Fixing It · K-2 Behavior Toolkit · Topic 6 of 12
Matchbook Learning Morning Meeting

Open fixing-it-student-deck-k2.html in Chrome to teach. Press N for notes.
Slide 1 has a Play the song button. Keep fixing-it-song.mp4 in this same folder so it plays.

Lee & Tee characters (c) AH-HA Coaching and Consulting, used with permission.
